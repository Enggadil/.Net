﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Introduction_to_Windows_form_Application
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // label3.Text = txtName.Text;
            //label3.Visible=true;


            MessageBox.Show(" Hi!" +" "+txtName.Text +" "+ "Welcome To My Application");
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
