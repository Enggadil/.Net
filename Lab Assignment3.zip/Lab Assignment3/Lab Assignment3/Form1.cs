﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Lab_Assignment3
{
    public partial class Form1 : Form
        
    {
        Form2 f2 = new Form2();
        SqlConnection con = new SqlConnection();
        DataTable dtUsers = new DataTable();
        string key = "Data Source=DESKTOP-OLCR3VL;Initial Catalog=BSSE_VP5;Integrated Security=True";

        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
              string query ="select * from users_table where User_Name='"+txtName.Text+"'and Password='"+txtPass.Text+"'";
            con.ConnectionString = key;
            con.Open();
            SqlCommand com = new SqlCommand(query, con);
          
            SqlDataAdapter sqd = new SqlDataAdapter(query, con);
           int a= sqd.Fill(dtUsers);
            if(a==1)
            { 
               // MessageBox.Show("Welcome User");
                con.Close();
                Form2 f2 = new Form2();
                    f2.Show();
         
            }
            else
            {
                MessageBox.Show("Wrong Entry ");
                con.Close();
            }
           
           // dataGridView1.DataSource = dtUsers;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }
    }
}
