﻿namespace CALCULATOR_APPLICATION_USING_WINFORM
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lbFN = new System.Windows.Forms.Label();
            this.lbSN = new System.Windows.Forms.Label();
            this.txtFN = new System.Windows.Forms.TextBox();
            this.txtSN = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSub = new System.Windows.Forms.Button();
            this.btnDiv = new System.Windows.Forms.Button();
            this.btnMul = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnRm = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Font = new System.Drawing.Font("Britannic Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(9, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(416, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "  MY CALCULATOR APPLICATION USING WINFORM";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbFN
            // 
            this.lbFN.AutoSize = true;
            this.lbFN.BackColor = System.Drawing.Color.Beige;
            this.lbFN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFN.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lbFN.Location = new System.Drawing.Point(27, 93);
            this.lbFN.Name = "lbFN";
            this.lbFN.Size = new System.Drawing.Size(146, 13);
            this.lbFN.TabIndex = 1;
            this.lbFN.Text = "ENTER FIRST NUMBER";
            // 
            // lbSN
            // 
            this.lbSN.AutoSize = true;
            this.lbSN.BackColor = System.Drawing.Color.Beige;
            this.lbSN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSN.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lbSN.Location = new System.Drawing.Point(27, 122);
            this.lbSN.Name = "lbSN";
            this.lbSN.Size = new System.Drawing.Size(161, 13);
            this.lbSN.TabIndex = 1;
            this.lbSN.Text = "ENTER SECOND NUMBER";
            // 
            // txtFN
            // 
            this.txtFN.Location = new System.Drawing.Point(216, 90);
            this.txtFN.Name = "txtFN";
            this.txtFN.Size = new System.Drawing.Size(144, 20);
            this.txtFN.TabIndex = 2;
            // 
            // txtSN
            // 
            this.txtSN.Location = new System.Drawing.Point(216, 119);
            this.txtSN.Name = "txtSN";
            this.txtSN.Size = new System.Drawing.Size(144, 20);
            this.txtSN.TabIndex = 2;
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnAdd.Location = new System.Drawing.Point(151, 269);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(101, 23);
            this.btnAdd.TabIndex = 3;
            this.btnAdd.Text = "Addition";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSub
            // 
            this.btnSub.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSub.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSub.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnSub.Location = new System.Drawing.Point(151, 169);
            this.btnSub.Name = "btnSub";
            this.btnSub.Size = new System.Drawing.Size(101, 23);
            this.btnSub.TabIndex = 3;
            this.btnSub.Text = "Substraction";
            this.btnSub.UseVisualStyleBackColor = false;
            this.btnSub.Click += new System.EventHandler(this.btnSub_Click);
            // 
            // btnDiv
            // 
            this.btnDiv.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDiv.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnDiv.Location = new System.Drawing.Point(151, 314);
            this.btnDiv.Name = "btnDiv";
            this.btnDiv.Size = new System.Drawing.Size(101, 23);
            this.btnDiv.TabIndex = 3;
            this.btnDiv.Text = "Division";
            this.btnDiv.UseVisualStyleBackColor = false;
            this.btnDiv.Click += new System.EventHandler(this.btnDiv_Click);
            // 
            // btnMul
            // 
            this.btnMul.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnMul.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMul.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnMul.Location = new System.Drawing.Point(151, 220);
            this.btnMul.Name = "btnMul";
            this.btnMul.Size = new System.Drawing.Size(101, 23);
            this.btnMul.TabIndex = 3;
            this.btnMul.Text = "Multiplication";
            this.btnMul.UseVisualStyleBackColor = false;
            this.btnMul.Click += new System.EventHandler(this.btnMul_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label2.Location = new System.Drawing.Point(148, 405);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Answer:";
            this.label2.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(213, 408);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "................";
            this.label3.Visible = false;
            // 
            // btnRm
            // 
            this.btnRm.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnRm.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRm.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnRm.Location = new System.Drawing.Point(151, 360);
            this.btnRm.Name = "btnRm";
            this.btnRm.Size = new System.Drawing.Size(101, 23);
            this.btnRm.TabIndex = 3;
            this.btnRm.Text = "Reminder";
            this.btnRm.UseVisualStyleBackColor = false;
            this.btnRm.Click += new System.EventHandler(this.btnDiv_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(437, 439);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnMul);
            this.Controls.Add(this.btnRm);
            this.Controls.Add(this.btnDiv);
            this.Controls.Add(this.btnSub);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtSN);
            this.Controls.Add(this.txtFN);
            this.Controls.Add(this.lbSN);
            this.Controls.Add(this.lbFN);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "  MY  CALCULATOR APP";
            this.TransparencyKey = System.Drawing.Color.Green;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbFN;
        private System.Windows.Forms.Label lbSN;
        private System.Windows.Forms.TextBox txtFN;
        private System.Windows.Forms.TextBox txtSN;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnSub;
        private System.Windows.Forms.Button btnDiv;
        private System.Windows.Forms.Button btnMul;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnRm;
    }
}

