﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CALCULATOR_APPLICATION_USING_WINFORM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtFN.Text!="" && txtSN.Text!="")
            {
                int num1 = int.Parse(txtFN.Text);
                int num2 = int.Parse(txtSN.Text);
                int result = num1 + num2;
                label3.Text = result.ToString();
                label3.Visible = true;
                label2.Visible = true;
                //MessageBox.Show("The Addition Of Two Number Is :" + " " + result.ToString());

            }
            else
            {
                MessageBox.Show("Please Fill Both Fields");
            }

        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            if (txtFN.Text != "" && txtSN.Text != "")
            {
                int num1 = int.Parse(txtFN.Text);
                int num2 = int.Parse(txtSN.Text);
                int result = num1 - num2;
                label3.Text = result.ToString();
                label3.Visible = true;
                label2.Visible = true;
                //MessageBox.Show("The Addition Of Two Number Is :" + " " + result.ToString());

            }
            else
            {
                MessageBox.Show("Please Fill Both Fields");
            }

        }

        private void btnMul_Click(object sender, EventArgs e)
        {
            if (txtFN.Text != "" && txtSN.Text != "")
            {
                int num1 = int.Parse(txtFN.Text);
                int num2 = int.Parse(txtSN.Text);
                int result = num1 *num2;
                label3.Text = result.ToString();
                label3.Visible = true;
                label2.Visible = true;
                //MessageBox.Show("The Addition Of Two Number Is :" + " " + result.ToString());

            }
            else
            {
                MessageBox.Show("Please Fill Both Fields");
            }
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (txtFN.Text != "" && txtSN.Text != "")
            {
                int num1 = int.Parse(txtFN.Text);
                int num2 = int.Parse(txtSN.Text);
                int result = num1 / num2;
                label3.Text = result.ToString();
                label3.Visible = true;
                label2.Visible = true;
                //MessageBox.Show("The Addition Of Two Number Is :" + " " + result.ToString());

            }
            else
            {
                MessageBox.Show("Please Fill Both Fields");
            }
        }

        private void btnRm_Click(object sender, EventArgs e)
        {
            if (txtFN.Text != "" && txtSN.Text != "")
            {
                int num1 = int.Parse(txtFN.Text);
                int num2 = int.Parse(txtSN.Text);
                int result = num1 % num2;
                label3.Text = result.ToString();
                label3.Visible = true;
                label2.Visible = true;
                //MessageBox.Show("The Addition Of Two Number Is :" + " " + result.ToString());

            }
            else
            {
                MessageBox.Show("Please Fill Both Fields");
            }
        }
    }
}
