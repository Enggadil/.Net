﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication5
{

    public partial class Form1 : Form
    {
        public static string fullname;
        public static string departurcity;
        public static string destination;
        public static string tripdates;
        public static string docno;
        public static string expiraydate;
        public static string estimatedbeggage;
        public static bool passport;
        public static bool idcard;
        bool cityfrom = true, CityTo = true, fname = true, documentno = true ;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dateTimePicker2.MinDate = dateTimePicker1.Value.AddDays(1);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            fullname = txtFn.Text + txtLn.Text;
            departurcity = txtFrom.Text;
            destination = txtTo.Text;
            docno = txtDn.Text;
            estimatedbeggage = numericUpDown1.Value.ToString();
            expiraydate = dateTimePicker2.Value.ToString("dd-MM-yyyy");
            tripdates = monthCalendar1.SelectionStart.ToString(format: "dd-MM-yyyy") + "  To   " + monthCalendar1.SelectionEnd.ToString(format: "dd-MM-yyyy");
            if (cityfrom==true || CityTo==true || fname==true || documentno == true)
            {
                MessageBox.Show("Error must be removed", "Error");
            }
            else
            {
                     Form2 f2 = new Form2();
            f2.Show();

            }
           


        }

        private void radioButtonpassport_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonpassport.Checked)
            {
                label7.Text = "Passport";
                passport = true;
                idcard = false;
            }

        }

        private void radioButtonidcard_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonidcard.Checked)
            {
                label7.Text = "Id card";
                idcard = true;
                passport = false;
            }

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateTimePicker2.MinDate = dateTimePicker1.Value.AddDays(1);
        }

        private void txtTo_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtFn_Validating(object sender, CancelEventArgs e)
        {
            if (txtFn.Text.Length < 3)
            {
                epFn.SetError(txtFn, "Must be greater then 3 digits");

            }
            else
            {
                epFn.SetError(txtFn, "");
                fname = false;


            }
        }

        private void txtDn_TextChanged(object sender, EventArgs e)
        {
            if (txtDn.Text.Length < 5)
            {
                epDoc.SetError(txtDn, "Must be greater then 5 digits");
                documentno = true;
            }
            else
            {
                epDoc.SetError(txtDn, "");
                documentno = false;
            }
        }

        private void txtFrom_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void txtFrom_Validating(object sender, CancelEventArgs e)
        {
            if (txtFrom.Text.Length < 1)
            {
                epForm.SetError(txtFrom, "It can not be null");

            }
            else
            {
                epForm.SetError(txtFrom, "");
                cityfrom = false;
            
            }

        }

        private void txtTo_Validating(object sender, CancelEventArgs e)
        {
            if (txtTo.Text.Length < 1)
            {
                epTo.SetError(txtTo, "It can not be null");

            }
            else
            {
                epTo.SetError(txtTo, "");
                CityTo = false;

            }
        }
    }
    
}
