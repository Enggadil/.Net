﻿namespace WindowsFormsApplication5
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lbFname = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbDepcity = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbDesCity = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbTripdate = new System.Windows.Forms.Label();
            this.lbDocNo = new System.Windows.Forms.Label();
            this.lbExpdate = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lbEb = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(5, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(461, 60);
            this.label1.TabIndex = 0;
            this.label1.Text = "we are looking your flight at cheapest rates.As soon as we gat a \r\nperfect match " +
    "we will send you an email notifaction.Check your \r\ndetails for reference ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbFname
            // 
            this.lbFname.AutoSize = true;
            this.lbFname.Location = new System.Drawing.Point(142, 92);
            this.lbFname.Name = "lbFname";
            this.lbFname.Size = new System.Drawing.Size(50, 13);
            this.lbFname.TabIndex = 1;
            this.lbFname.Text = "Summary";
            this.lbFname.Click += new System.EventHandler(this.lbFname_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(54, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Full name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(41, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Departure City";
            // 
            // lbDepcity
            // 
            this.lbDepcity.AutoSize = true;
            this.lbDepcity.Location = new System.Drawing.Point(142, 138);
            this.lbDepcity.Name = "lbDepcity";
            this.lbDepcity.Size = new System.Drawing.Size(50, 13);
            this.lbDepcity.TabIndex = 4;
            this.lbDepcity.Text = "Summary";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(41, 173);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Destination city";
            // 
            // lbDesCity
            // 
            this.lbDesCity.AutoSize = true;
            this.lbDesCity.Location = new System.Drawing.Point(142, 173);
            this.lbDesCity.Name = "lbDesCity";
            this.lbDesCity.Size = new System.Drawing.Size(50, 13);
            this.lbDesCity.TabIndex = 6;
            this.lbDesCity.Text = "Summary";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(56, 210);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Trip Dates";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(56, 241);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Document No";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(56, 272);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Expiray date";
            // 
            // lbTripdate
            // 
            this.lbTripdate.AutoSize = true;
            this.lbTripdate.Location = new System.Drawing.Point(142, 210);
            this.lbTripdate.Name = "lbTripdate";
            this.lbTripdate.Size = new System.Drawing.Size(50, 13);
            this.lbTripdate.TabIndex = 10;
            this.lbTripdate.Text = "Summary";
            // 
            // lbDocNo
            // 
            this.lbDocNo.AutoSize = true;
            this.lbDocNo.Location = new System.Drawing.Point(142, 241);
            this.lbDocNo.Name = "lbDocNo";
            this.lbDocNo.Size = new System.Drawing.Size(50, 13);
            this.lbDocNo.TabIndex = 11;
            this.lbDocNo.Text = "Summary";
            // 
            // lbExpdate
            // 
            this.lbExpdate.AutoSize = true;
            this.lbExpdate.Location = new System.Drawing.Point(142, 272);
            this.lbExpdate.Name = "lbExpdate";
            this.lbExpdate.Size = new System.Drawing.Size(50, 13);
            this.lbExpdate.TabIndex = 12;
            this.lbExpdate.Text = "Summary";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(13, 301);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(108, 13);
            this.label14.TabIndex = 13;
            this.label14.Text = "esstimated baaggage";
            // 
            // lbEb
            // 
            this.lbEb.AutoSize = true;
            this.lbEb.Location = new System.Drawing.Point(142, 301);
            this.lbEb.Name = "lbEb";
            this.lbEb.Size = new System.Drawing.Size(50, 13);
            this.lbEb.TabIndex = 14;
            this.lbEb.Text = "Summary";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Location = new System.Drawing.Point(-6, 353);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(488, 32);
            this.button1.TabIndex = 15;
            this.button1.Text = "Done";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(478, 385);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lbEb);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.lbExpdate);
            this.Controls.Add(this.lbDocNo);
            this.Controls.Add(this.lbTripdate);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lbDesCity);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbDepcity);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbFname);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Booking Summary";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form2_FormClosed);
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbFname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbDepcity;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbDesCity;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbTripdate;
        private System.Windows.Forms.Label lbDocNo;
        private System.Windows.Forms.Label lbExpdate;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lbEb;
        private System.Windows.Forms.Button button1;
    }
}