﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication5
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            lbFname.Text = Form1.fullname;
            lbDepcity.Text = Form1.departurcity;
            lbDesCity.Text = Form1.destination;
            lbTripdate.Text = Form1.tripdates;
            lbExpdate.Text = Form1.expiraydate;
            lbDocNo.Text = Form1.docno;
            lbEb.Text = Form1.estimatedbeggage;
        if(Form1.passport==true)
            {
                label9.Text = "passport number";
            }
        if(Form1.idcard==true)
            {
                label9.Text = "Id Card";
            }
        }

        private void lbFname_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
